#include <string>
#include <unordered_map>
#include <iostream>

#include "state.h"
#include "automaton.h"


int main() {
    Automaton automata;
    automata.lexer("archivo.txt");
}
