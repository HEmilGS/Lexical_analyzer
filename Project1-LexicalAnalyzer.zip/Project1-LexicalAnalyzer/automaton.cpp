#include "automaton.h"  // Inclusi�n de los archivos de encabezado necesarios
#include "state.h"
#include <iostream>
#include <string>
#include <fstream>
#include <queue>


// Constructor de la clase Automaton
Automaton::Automaton() : currentState("Initial state", true, false), // Se inicializan los estados del aut�mata
assignment("Assignment", true, false),
sum("Sum", true, false),
substract("Substract", true, false),
product("Product", true, false),
division("Division", true, false),
variable("Variable", true, false),
lParenthesis("lParenthesis", true, false),
rParenthesis("rParenthesis", true, false),
floats("float", true, false),
ints("int", true, false),
deathState("Death state", true, true) {


    // Se definen las transiciones entre los estados
    currentState.addTransition("assignment", assignment);
    currentState.addTransition("sum", sum);
    currentState.addTransition("substract", substract);
    currentState.addTransition("product", product);
    currentState.addTransition("division", division);
    currentState.addTransition("variable", variable);
    currentState.addTransition("lP", lParenthesis);
    currentState.addTransition("rP", rParenthesis);
    currentState.addTransition("float", floats);
    currentState.addTransition("int", ints);

    // Se agregan las transiciones para cada estado hacia s� mismo y hacia el estado de muerte
    assignment.addTransition("assignment", assignment);
    assignment.addTransition("sum", sum);
    assignment.addTransition("substract", substract);
    assignment.addTransition("product", product);
    assignment.addTransition("Ddivision", division);
    assignment.addTransition("variable", variable);
    assignment.addTransition("lP", lParenthesis);
    assignment.addTransition("rP", rParenthesis);
    assignment.addTransition("float", floats);
    assignment.addTransition("int", ints);

    sum.addTransition("assignment", assignment);
    sum.addTransition("sum", sum);
    sum.addTransition("substract", substract);
    sum.addTransition("product", product);
    sum.addTransition("division", division);
    sum.addTransition("variable", variable);
    sum.addTransition("lP", lParenthesis);
    sum.addTransition("rP", rParenthesis);
    sum.addTransition("float", floats);
    sum.addTransition("int", ints);

    substract.addTransition("assignment", assignment);
    substract.addTransition("sum", sum);
    substract.addTransition("substract", substract);
    substract.addTransition("product", product);
    substract.addTransition("division", division);
    substract.addTransition("variable", variable);
    substract.addTransition("lP", lParenthesis);
    substract.addTransition("rP", rParenthesis);
    substract.addTransition("float", floats);
    substract.addTransition("int", ints);

    product.addTransition("assignment", assignment);
    product.addTransition("sum", sum);
    product.addTransition("substract", substract);
    product.addTransition("product", product);
    product.addTransition("division", division);
    product.addTransition("variable", variable);
    product.addTransition("lP", lParenthesis);
    product.addTransition("rP", rParenthesis);
    product.addTransition("float", floats);
    product.addTransition("int", ints);

    division.addTransition("assignment", assignment);
    division.addTransition("sum", sum);
    division.addTransition("substract", substract);
    division.addTransition("product", product);
    division.addTransition("division", division);
    division.addTransition("variable", variable);
    division.addTransition("lP", lParenthesis);
    division.addTransition("rP", rParenthesis);
    division.addTransition("float", floats);
    division.addTransition("int", ints);

    variable.addTransition("assignment", assignment);
    variable.addTransition("sum", sum);
    variable.addTransition("substract", substract);
    variable.addTransition("product", product);
    variable.addTransition("division", division);
    variable.addTransition("variable", variable);
    variable.addTransition("lP", lParenthesis);
    variable.addTransition("rP", rParenthesis);
    variable.addTransition("float", floats);
    variable.addTransition("int", ints);

    lParenthesis.addTransition("assignment", assignment);
    lParenthesis.addTransition("sum", sum);
    lParenthesis.addTransition("substract", substract);
    lParenthesis.addTransition("product", product);
    lParenthesis.addTransition("division", division);
    lParenthesis.addTransition("variable", variable);
    lParenthesis.addTransition("lP", lParenthesis);
    lParenthesis.addTransition("rP", rParenthesis);
    lParenthesis.addTransition("float", floats);
    lParenthesis.addTransition("int", ints);

    rParenthesis.addTransition("assignment", assignment);
    rParenthesis.addTransition("sum", sum);
    rParenthesis.addTransition("substract", substract);
    rParenthesis.addTransition("product", product);
    rParenthesis.addTransition("division", division);
    rParenthesis.addTransition("variable", variable);
    rParenthesis.addTransition("lP", lParenthesis);
    rParenthesis.addTransition("rP", rParenthesis);
    rParenthesis.addTransition("float", floats);
    rParenthesis.addTransition("int", ints);

    floats.addTransition("assignment", assignment);
    floats.addTransition("sum", sum);
    floats.addTransition("substract", substract);
    floats.addTransition("product", product);
    floats.addTransition("division", division);
    floats.addTransition("variable", variable);
    floats.addTransition("lP", lParenthesis);
    floats.addTransition("rP", rParenthesis);
    floats.addTransition("float", floats);
    floats.addTransition("int", ints);

    ints.addTransition("assignment", assignment);
    ints.addTransition("sum", sum);
    ints.addTransition("substract", substract);
    ints.addTransition("product", product);
    ints.addTransition("division", division);
    ints.addTransition("variable", variable);
    ints.addTransition("lP", lParenthesis);
    ints.addTransition("rP", rParenthesis);
    ints.addTransition("float", floats);
    ints.addTransition("int", ints);

    // Se a�aden transiciones hacia el estado de muerte
    assignment.addTransition("death", deathState);
    sum.addTransition("death", deathState);
    substract.addTransition("death", deathState);
    product.addTransition("death", deathState);
    division.addTransition("death", deathState);
    variable.addTransition("death", deathState);
    lParenthesis.addTransition("death", deathState);
    rParenthesis.addTransition("death", deathState);
    floats.addTransition("death", deathState);
    ints.addTransition("death", deathState);
}

// M�todo para intercambiar estados
State Automaton::swap(State next) {
    // Se agregan las transiciones necesarias al estado pasado como argumento
    next.addTransition("assignment", assignment);
    next.addTransition("sum", sum);
    next.addTransition("substract", substract);
    next.addTransition("product", product);
    next.addTransition("division", division);
    next.addTransition("variable", variable);
    next.addTransition("lP", lParenthesis);
    next.addTransition("rP", rParenthesis);
    next.addTransition("float", floats);
    next.addTransition("int", ints);
    next.addTransition("death", deathState);

    return next; // Se devuelve el estado modificado
}

// M�todo para analizar el archivo fuente
void Automaton::lexer(std::string filename) {
    std::ifstream file; // Se abre el archivo
    file.open(filename); // Se abre el archivo con el nombre proporcionado

    if (!file) { // Si no se puede abrir el archivo, se muestra un mensaje de error
        std::cout << "Unable to open  file";
    }
    else { // Si se abre correctamente
        std::string line;
        while (std::getline(file, line)) { // Se lee l�nea por l�nea del archivo
            validate(line); // Se valida cada l�nea
        }
        file.close(); // Se cierra el archivo
    }
}

// M�todo para validar una l�nea de c�digo
void Automaton::validate(std::string line) {
    if (line.length() != 0) { // Si la l�nea no est� vac�a
        State next; // Se inicializa un nuevo estado
        std::string symbol; // Variable para almacenar el s�mbolo actual
        int cont = 0; // Contador para avanzar en la l�nea
        std::queue<char> colaDeValidacion; // Cola para validar
        bool DigitFound = false, realEncontrado = false; // Variables de control

        for (int i = 0; i < line.length(); i++) { // Se recorre cada car�cter de la l�nea
            if (line[i] != ' ') { // Se ignora el espacio en blanco
                if (std::isdigit(line[i])) { // Si el car�cter es un d�gito
                    next = currentState.nextState("int"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    while (isdigit(line[i + cont]) || line[i + cont] == '.') { // Mientras se encuentren d�gitos o puntos
                        if (line[i + cont] == '.' && std::isdigit(line[i + cont + 1])) { // Si se encuentra un punto seguido de un d�gito
                            realEncontrado = true; // Se indica que se encontr� un n�mero real
                        }
                        symbol = symbol + line[i + cont];
                        size_t dotfound = symbol.find("."); // Se busca un punto en el s�mbolo
                        if (dotfound != std::string::npos) { // Si se encuentra un punto
                            realEncontrado = true; // Se indica que se encontr� un n�mero real
                        }
                        cont++; // Se avanza en la l�nea
                        DigitFound = true; // Se indica que se encontr� un d�gito
                    }
                    i = i + symbol.length() - 1; // Se ajusta el �ndice
                    if (DigitFound && realEncontrado) { // Si se encontr� un n�mero real
                        next = currentState.nextState("float"); // Se obtiene el pr�ximo estado
                        currentState = swap(next); // Se cambia al pr�ximo estado
                        currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                        std::cout << std::endl; // Se imprime un salto de l�nea
                        realEncontrado = false; // Se reinicia la bandera
                        cont = 0; // Se reinicia el contador
                        symbol = ""; // Se reinicia el s�mbolo
                    }
                    else if (DigitFound) { // Si se encontr� un n�mero entero
                        currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                        std::cout << std::endl; // Se imprime un salto de l�nea
                        cont = 0; // Se reinicia el contador
                        symbol = ""; // Se reinicia el s�mbolo
                    }
                }
                else if (std::isalpha(line[i])) { // Si el car�cter es una letra
                    next = currentState.nextState("variable"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    while (isalpha(line[i + cont])) { // Mientras se encuentren letras
                        symbol = symbol + line[i + cont];
                        //colaDeValidacion.pop(); // Se elimina el car�cter de la cola
                        cont++; // Se avanza en la l�nea
                        DigitFound = true; // Se indica que se encontr� una letra
                    }
                    i = i + symbol.length() - 1; // Se ajusta el �ndice
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    if (DigitFound) { // Si se encontr� una letra
                        cont = 0; // Se reinicia el contador
                        symbol = ""; // Se reinicia el s�mbolo
                    }
                }
                else if (line[i] == '=') { // si especificar// Si el car�cter es un operador
                    next = currentState.nextState("assignment"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else if (line[i] == '+') {
                    next = currentState.nextState("sum"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else if (line[i] == '-') {
                    next = currentState.nextState("substract"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else if (line[i] == '*') {
                    next = currentState.nextState("product"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else if (line[i] == '/') {
					next = currentState.nextState("division"); // Se obtiene el pr�ximo estado
					currentState = swap(next); // Se cambia al pr�ximo estado
					std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
					currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
					std::cout << std::endl; // Se imprime un salto de l�nea
					symbol = ""; // Se reinicia el s�mbolo
				}
                else if (line[i] == '(') { // Si el car�cter es un par�ntesis izquierdo
                    next = currentState.nextState("lP"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else if (line[i] == ')') { // Si el car�cter es un par�ntesis derecho
                    next = currentState.nextState("rP"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    std::cout << std::endl; // Se imprime un salto de l�nea
                    symbol = ""; // Se reinicia el s�mbolo
                }
                else { // Si el car�cter no es reconocido
                    next = currentState.nextState("death"); // Se obtiene el pr�ximo estado
                    currentState = swap(next); // Se cambia al pr�ximo estado
                    std::string symbol(1, line[i]); // Se convierte el car�cter a cadena
                    currentState.toString(symbol, currentState.label); // Se muestra el s�mbolo
                    symbol = ""; // Se reinicia el s�mbolo
                }
            }
        }
    }
}
